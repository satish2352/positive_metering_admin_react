// api/config.js
export const API_BASE_URL = "http://localhost:5000";

export const endpoints = {
  bloglist: `${API_BASE_URL}/bloglist`,
  // Add other endpoints here as needed
};