import { AreaCards, AreaCharts, AreaTable, AreaTop } from "../../components";

const Dashboard = () => {
  return (
    <div className="content-area">
      {/* <AreaTop /> */}
    </div>
  );
};

export default Dashboard;
